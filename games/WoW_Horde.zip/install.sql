-- phpMyAdmin SQL Dump
-- version 2.9.0.3
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: May 19, 2007 at 07:44 AM
-- Server version: 5.0.27
-- PHP Version: 5.2.0
-- 
-- Database: `phpraider`
-- 

-- 
-- Dumping data for table `phpraider_attribute`
-- 

INSERT INTO `phpraider_attribute` (`attribute_id`, `att_name`, `att_type`, `att_min`, `att_max`, `att_hover`, `att_show`, `att_icon`) VALUES 
(1, 'Arcane Resistance', 'numeric', 0, 0, 0, 1, 'arcane_resistance.png'),
(2, 'Fire Resistance', 'numeric', 0, 0, 0, 1, 'fire_resistance.png'),
(3, 'Frost Resistance', 'numeric', 0, 0, 0, 1, 'frost_resistance.png'),
(4, 'Nature Resistance', 'numeric', 0, 0, 0, 1, 'nature_resistance.png'),
(5, 'Shadow Resistance', 'numeric', 0, 0, 0, 1, 'shadow_resistance.png'),
(6, 'Damage Gear', 'numeric', 0, 0, 0, 1, 'damage_gear.png'),
(7, 'Healing Gear', 'numeric', 0, 0, 0, 1, 'healing_gear.png');

-- 
-- Dumping data for table `phpraider_class`
-- 

INSERT INTO `phpraider_class` (`class_id`, `class_color`, `class_name`) VALUES 
(1, 'Orange', 'Druid'),
(2, 'Green', 'Hunter'),
(3, 'Cyan', 'Mage'),
(4, 'Blue', 'Paladin'),
(5, 'Grey', 'Priest'),
(6, 'Gold', 'Rogue'),
(7, 'Magenta', 'Shaman'),
(8, 'Purple', 'Warlock'),
(9, 'Brown', 'Warrior'),
(10,'Crimson','Death Knight');

-- 
-- Dumping data for table `phpraider_definitions`
-- 

INSERT INTO `phpraider_definitions` (`class_id`, `race_id`) VALUES 
(1,8),
(2,1),
(2,7),
(2,8),
(2,9),
(3,1),
(3,9),
(3,10),
(4,1),
(5,1),
(5,9),
(5,10),
(6,1),
(6,7),
(6,9),
(6,10),
(7,7),
(7,8),
(7,9),
(8,1),
(8,7),
(8,10),
(9,7),
(9,8),
(9,9),
(9,10),
(10,1),
(10,7),
(10,8),
(10,9),
(10,10);

-- 
-- Dumping data for table `phpraider_gender`
-- 

INSERT INTO `phpraider_gender` (`gender_id`, `gender_name`) VALUES 
(1, 'Male'),
(2, 'Female');

-- 
-- Dumping data for table `phpraider_race`
-- 

INSERT INTO `phpraider_race` (`race_id`, `race_name`) VALUES 
(1, 'Blood Elf'),
(7, 'Orc'),
(8, 'Tauren'),
(9, 'Troll'),
(10, 'Undead');

-- 
-- Dumping data for table `phpraider_role`
-- 

INSERT INTO `phpraider_role` (`role_id`, `role_name`, `body_color`, `header_color`, `font_color`) VALUES 
(1, 'DPS', 'white', '0099ff', 'black'),
(2, 'Main Tank', 'white', '0099ff', 'black'),
(3, 'Off Tank', 'white', '0099ff', 'black'),
(4, 'Healer', 'white', '0099ff', 'black'),
(5, 'Hybrid', 'white', '0099ff', 'black');
